
import { useEffect, useState } from "react";
import { loadGoogleMapsScript } from "@/lib/googleMaps";

type GooglePlacesResult = {
  isReady: boolean;
  error: Error | null;
};

export function useGooglePlaces(): GooglePlacesResult {
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    loadGoogleMapsScript()
      .then(() => setIsReady(true))
      .catch((err) => setError(err));
  }, []);

  return { isReady, error };
}

export default useGooglePlaces;
