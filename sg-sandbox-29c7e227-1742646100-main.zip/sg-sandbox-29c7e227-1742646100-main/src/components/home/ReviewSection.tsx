
import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import Image from "next/image";

interface Review {
  id: string;
  author: string;
  rating: number;
  content: string;
  avatar: string;
  location: string;
}

const demoReviews: Review[] = [
  {
    id: "1",
    author: "John Smith",
    rating: 5,
    content: "Exceptional service! The chauffeur was professional and punctual.",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100",
    location: "New York"
  },
  {
    id: "2",
    author: "Emma Wilson",
    rating: 5,
    content: "Luxurious vehicles and outstanding customer service.",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100",
    location: "London"
  },
  {
    id: "3",
    author: "Michael Chen",
    rating: 5,
    content: "Always reliable and comfortable. My go-to chauffeur service.",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100",
    location: "Singapore"
  }
];

export function ReviewSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            What Our Clients Say
          </h2>
          <p className="text-lg text-gray-600">
            Trusted by thousands of travelers worldwide
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {demoReviews.map((review) => (
            <Card key={review.id} className="bg-white">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden">
                    <Image
                      src={review.avatar}
                      alt={review.author}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-semibold">{review.author}</h3>
                    <p className="text-sm text-gray-500">{review.location}</p>
                  </div>
                </div>
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600">{review.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
