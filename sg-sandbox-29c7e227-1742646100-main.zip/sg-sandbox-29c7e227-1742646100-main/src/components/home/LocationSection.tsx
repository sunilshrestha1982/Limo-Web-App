
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import Link from "next/link";

interface CityDestination {
  id: string;
  name: string;
  image: string;
  description: string;
  slug: string;
}

const popularDestinations: CityDestination[] = [
  {
    id: "1",
    name: "New York",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&h=400",
    description: "Luxury transfers in the Big Apple",
    slug: "new-york"
  },
  {
    id: "2",
    name: "London",
    image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&h=400",
    description: "Premium chauffeur service in London",
    slug: "london"
  },
  {
    id: "3",
    name: "Dubai",
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&h=400",
    description: "Exclusive transportation in Dubai",
    slug: "dubai"
  }
];

export function LocationSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Popular Destinations
          </h2>
          <p className="text-lg text-gray-600">
            Premium chauffeur services in major cities worldwide
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {popularDestinations.map((destination) => (
            <Link href={`/cities/${destination.slug}`} key={destination.id}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-48">
                  <Image
                    src={destination.image}
                    alt={destination.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{destination.name}</h3>
                  <p className="text-gray-600 mb-4">{destination.description}</p>
                  <Button variant="outline" className="w-full">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
