import Link from "next/link";
import Image from "next/image";
import { Separator } from "@/components/ui/separator";
import { useEffect, useState } from "react";
import { configService } from "@/services/configService";
import { SiteConfig } from "@/types/config";
import { Alert, AlertDescription } from '@/components/ui/alert';

export function Footer() {
  const [config, setConfig] = useState<SiteConfig | null>(null);

  useEffect(() => {
    const loadConfig = async () => {
      const siteConfig = await configService.getSiteConfig();
      setConfig(siteConfig);
    };
    loadConfig();
  }, []);

  if (!config) {
    return (
      <footer className='bg-gray-900 text-white'>
        <div className='container mx-auto px-4 py-12'>
          <div className='grid md:grid-cols-4 gap-8'>
            <div className='h-10 w-32 bg-gray-800 animate-pulse rounded' />
          </div>
          <div className='mt-8'>
            <Alert variant='default' className='bg-gray-800 border-gray-700'>
              <AlertDescription className='text-gray-400'>
                © {new Date().getFullYear()} Premium Chauffeur Service. All rights reserved.
              </AlertDescription>
            </Alert>
          </div>
        </div>
      </footer>
    );
  }

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="mb-4">
              {config?.branding.logo.light ? (
                <Image
                  src={config.branding.logo.light}
                  alt="Logo"
                  width={120}
                  height={40}
                  className="h-10 w-auto"
                />
              ) : (
                <div className="h-10 w-32 bg-gray-800 animate-pulse rounded" />
              )}
            </div>
            <p className="text-gray-400">
              {config?.branding.slogan || "Premium chauffeur service worldwide. Experience luxury and comfort in over 50 countries."}
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Services</h3>
            <ul className="space-y-2">
              <li><Link href="/services/airport-transfer" className="text-gray-400 hover:text-white">Airport Transfers</Link></li>
              <li><Link href="/services/hourly-booking" className="text-gray-400 hover:text-white">Hourly Booking</Link></li>
              <li><Link href="/services/corporate" className="text-gray-400 hover:text-white">Corporate Service</Link></li>
              <li><Link href="/services/events" className="text-gray-400 hover:text-white">Event Transportation</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-400 hover:text-white">About Us</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              <li><Link href="/careers" className="text-gray-400 hover:text-white">Careers</Link></li>
              <li><Link href="/blog" className="text-gray-400 hover:text-white">Blog</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link href="/terms" className="text-gray-400 hover:text-white">Terms of Service</Link></li>
              <li><Link href="/privacy" className="text-gray-400 hover:text-white">Privacy Policy</Link></li>
              <li><Link href="/cookies" className="text-gray-400 hover:text-white">Cookie Policy</Link></li>
              <li><Link href="/faq" className="text-gray-400 hover:text-white">FAQ</Link></li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-gray-800" />

        <div className="text-center text-gray-400 text-sm">
          © {new Date().getFullYear()} {config?.branding.slogan || "Premium Chauffeur Service"}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}