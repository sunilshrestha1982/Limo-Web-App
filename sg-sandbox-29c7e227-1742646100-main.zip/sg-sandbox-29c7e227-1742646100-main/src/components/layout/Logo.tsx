
import Image from "next/image";
import { useEffect, useState } from "react";
import { configService } from "@/services/configService";
import { SiteConfig } from "@/types/config";

interface LogoProps {
  variant?: "light" | "dark";
  className?: string;
}

export function Logo({ variant = "dark", className = "h-10 w-auto" }: LogoProps) {
  const [config, setConfig] = useState<SiteConfig | null>(null);

  useEffect(() => {
    const loadConfig = async () => {
      try {
        const siteConfig = await configService.getSiteConfig();
        setConfig(siteConfig);
      } catch (error) {
        console.error("Error loading config:", error);
      }
    };
    loadConfig();
  }, []);

  if (!config) {
    return <div className={`bg-gray-200 animate-pulse rounded ${className}`} />;
  }

  const logoUrl = variant === "light" ? config.branding.logo.light : config.branding.logo.dark;

  if (!logoUrl) {
    return <div className={`bg-gray-200 animate-pulse rounded ${className}`} />;
  }

  return (
    <Image
      src={logoUrl}
      alt={config.branding.slogan || "Logo"}
      width={120}
      height={40}
      className={className}
      priority
    />
  );
}
