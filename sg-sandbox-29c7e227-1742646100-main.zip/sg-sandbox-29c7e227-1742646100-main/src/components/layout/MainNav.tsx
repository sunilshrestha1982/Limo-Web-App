
import Link from "next/link";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

export function MainNav() {
  return (
    <NavigationMenu>
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Services</NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="grid w-[400px] gap-3 p-4">
              <Link href="/services/airport-transfer" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">Airport Transfers</div>
                <p className="text-sm text-muted-foreground">Professional airport pickup and dropoff service</p>
              </Link>
              <Link href="/services/hourly-booking" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">Hourly Booking</div>
                <p className="text-sm text-muted-foreground">Flexible hourly chauffeur service</p>
              </Link>
              <Link href="/services/corporate" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">Corporate Service</div>
                <p className="text-sm text-muted-foreground">Business travel and event transportation</p>
              </Link>
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>

        <NavigationMenuItem>
          <NavigationMenuTrigger>Fleet</NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="grid w-[400px] gap-3 p-4">
              <Link href="/fleet/first-class" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">First Class</div>
                <p className="text-sm text-muted-foreground">Mercedes-Benz S-Class or similar</p>
              </Link>
              <Link href="/fleet/business-van" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">Business Van</div>
                <p className="text-sm text-muted-foreground">Mercedes-Benz V-Class or similar</p>
              </Link>
              <Link href="/fleet/business" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">Business Class</div>
                <p className="text-sm text-muted-foreground">BMW 5 Series or similar</p>
              </Link>
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>

        <NavigationMenuItem>
          <NavigationMenuTrigger>Cities</NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="grid w-[400px] gap-3 p-4">
              <Link href="/cities/new-york" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">New York</div>
                <p className="text-sm text-muted-foreground">Luxury transfers in the Big Apple</p>
              </Link>
              <Link href="/cities/london" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">London</div>
                <p className="text-sm text-muted-foreground">Premium service in London</p>
              </Link>
              <Link href="/cities/dubai" className="block p-3 hover:bg-accent">
                <div className="text-sm font-medium">Dubai</div>
                <p className="text-sm text-muted-foreground">Exclusive transportation in Dubai</p>
              </Link>
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>

        <NavigationMenuItem>
          <Link href="/about" legacyBehavior passHref>
            <NavigationMenuLink className="group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50">
              About
            </NavigationMenuLink>
          </Link>
        </NavigationMenuItem>

        <NavigationMenuItem>
          <Link href="/contact" legacyBehavior passHref>
            <NavigationMenuLink className="group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50">
              Contact
            </NavigationMenuLink>
          </Link>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  );
}
