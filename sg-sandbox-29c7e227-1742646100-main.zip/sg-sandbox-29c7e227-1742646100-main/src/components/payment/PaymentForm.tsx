
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PaymentMethod } from "@/types/payment";

interface PaymentFormProps {
  amount: number;
  onSubmit: (paymentMethod: PaymentMethod) => void;
}

export function PaymentForm({ amount, onSubmit }: PaymentFormProps) {
  const [paymentType, setPaymentType] = useState<PaymentMethod["type"]>("credit_card");
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const [month, year] = expiryDate.split("/");
    
    const paymentMethod: PaymentMethod = {
      id: Date.now().toString(),
      type: paymentType,
      last4: cardNumber.slice(-4),
      brand: "visa", // This would come from Stripe
      expiryMonth: parseInt(month),
      expiryYear: parseInt(year)
    };

    onSubmit(paymentMethod);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment Details</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Select value={paymentType} onValueChange={(value: PaymentMethod["type"]) => setPaymentType(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="credit_card">Credit Card</SelectItem>
                <SelectItem value="google_pay">Google Pay</SelectItem>
                <SelectItem value="apple_pay">Apple Pay</SelectItem>
                <SelectItem value="authorize_net">Authorize.net</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {paymentType === "credit_card" && (
            <>
              <Input
                placeholder="Card Number"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
              />
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="MM/YY"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                />
                <Input
                  placeholder="CVV"
                  type="password"
                  maxLength={3}
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value)}
                />
              </div>
            </>
          )}

          <div className="text-xl font-semibold">
            Total Amount: ${amount.toFixed(2)}
          </div>

          <Button type="submit" className="w-full">
            Pay Now
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
