
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface TipSelectorProps {
  amount: number;
  onTipChange: (tipAmount: number) => void;
}

export function TipSelector({ amount, onTipChange }: TipSelectorProps) {
  const [customTip, setCustomTip] = useState("");
  const [selectedTipPercentage, setSelectedTipPercentage] = useState<number | null>(null);

  const tipPercentages = [15, 18, 20];

  const handleTipSelect = (percentage: number) => {
    setSelectedTipPercentage(percentage);
    setCustomTip("");
    const tipAmount = (amount * percentage) / 100;
    onTipChange(tipAmount);
  };

  const handleCustomTipChange = (value: string) => {
    setCustomTip(value);
    setSelectedTipPercentage(null);
    const tipAmount = parseFloat(value) || 0;
    onTipChange(tipAmount);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add a Tip</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            {tipPercentages.map((percentage) => (
              <Button
                key={percentage}
                variant={selectedTipPercentage === percentage ? "default" : "outline"}
                onClick={() => handleTipSelect(percentage)}
              >
                {percentage}%
              </Button>
            ))}
          </div>
          <div className="relative">
            <Input
              type="number"
              placeholder="Custom Amount"
              value={customTip}
              onChange={(e) => handleCustomTipChange(e.target.value)}
              className="pl-6"
            />
            <span className="absolute left-2 top-1/2 -translate-y-1/2">$</span>
          </div>
          {(selectedTipPercentage || customTip) && (
            <div className="text-sm text-gray-600">
              Tip Amount: ${((selectedTipPercentage ? (amount * selectedTipPercentage) / 100 : parseFloat(customTip)) || 0).toFixed(2)}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
