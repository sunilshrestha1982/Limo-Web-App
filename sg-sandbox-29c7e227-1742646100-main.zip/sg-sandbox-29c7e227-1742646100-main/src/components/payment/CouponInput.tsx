import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { paymentService } from "@/services/paymentService";

interface CouponInputProps {
  amount: number;
  onCouponApply: (discountAmount: number) => void;
}

export function CouponInput({ amount, onCouponApply }: CouponInputProps) {
  const [couponCode, setCouponCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [discountType, setDiscountType] = useState<'fixed' | 'percentage'>('fixed');
  const [discountValue, setDiscountValue] = useState(0);

  const handleApplyCoupon = async () => {
    try {
      setLoading(true);
      setError("");
      
      const coupon = await paymentService.validateCoupon(couponCode, amount);
      
      if (!coupon) {
        setError("Invalid or expired coupon code");
        return;
      }

      const discount = await paymentService.calculateDiscount(amount, coupon);
      setDiscountType(coupon.discountType);
      setDiscountValue(coupon.discountAmount);
      setAppliedDiscount(discount);
      onCouponApply(discount);
    } catch (error) {
      setError("Error applying coupon");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          placeholder="Enter coupon code"
          value={couponCode}
          onChange={(e) => setCouponCode(e.target.value)}
        />
        <Button 
          onClick={handleApplyCoupon}
          disabled={loading || !couponCode}
        >
          Apply
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {appliedDiscount > 0 && (
        <Alert>
          <AlertDescription>
            {discountType === 'percentage' 
              ? `Discount applied: ${discountValue}% (${appliedDiscount.toFixed(2)}$)`
              : `Discount applied: $${appliedDiscount.toFixed(2)}`
            }
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}