
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bell, CheckCircle, XCircle } from "lucide-react";

interface Notification {
  id: string;
  type: "booking" | "document" | "system";
  title: string;
  message: string;
  status: "unread" | "read";
  timestamp: string;
}

interface NotificationPanelProps {
  notifications: Notification[];
  onNotificationRead: (id: string) => void;
}

export function NotificationPanel({ notifications, onNotificationRead }: NotificationPanelProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notifications
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 rounded-lg border ${
                notification.status === "unread"
                  ? "bg-gray-50 border-gray-200"
                  : "bg-white border-gray-100"
              }`}
              onClick={() => onNotificationRead(notification.id)}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-semibold">{notification.title}</h4>
                  <p className="text-sm text-gray-600">{notification.message}</p>
                </div>
                {notification.status === "unread" ? (
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-gray-400" />
                )}
              </div>
              <div className="mt-2 text-xs text-gray-500">
                {new Date(notification.timestamp).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
