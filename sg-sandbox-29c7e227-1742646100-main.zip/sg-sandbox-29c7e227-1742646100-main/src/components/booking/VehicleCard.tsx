
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Vehicle } from "@/types/booking";
import Image from "next/image";

interface VehicleCardProps {
  vehicle: Vehicle;
  onSelect: (vehicle: Vehicle) => void;
  selected?: boolean;
}

export function VehicleCard({ vehicle, onSelect, selected }: VehicleCardProps) {
  return (
    <Card className={`relative overflow-hidden transition-all ${selected ? "ring-2 ring-primary" : ""}`}>
      <CardHeader>
        <div className="relative w-full h-48">
          <Image
            src={vehicle.imageUrl}
            alt={vehicle.name}
            fill
            className="object-cover rounded-t-lg"
          />
        </div>
        <CardTitle className="mt-4">{vehicle.name}</CardTitle>
        <CardDescription>{vehicle.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span>Capacity</span>
            <span>{vehicle.capacity} passengers</span>
          </div>
          <div className="flex justify-between">
            <span>Hourly Rate</span>
            <span>${vehicle.hourlyRate}/hour</span>
          </div>
          <div className="flex justify-between">
            <span>Base Rate</span>
            <span>${vehicle.baseRate}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          className="w-full" 
          onClick={() => onSelect(vehicle)}
          variant={selected ? "secondary" : "default"}
        >
          {selected ? "Selected" : "Select Vehicle"}
        </Button>
      </CardFooter>
    </Card>
  );
}
