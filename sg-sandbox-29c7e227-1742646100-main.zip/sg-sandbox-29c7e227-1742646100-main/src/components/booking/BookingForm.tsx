
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { BookingFormData } from "@/types/booking";
import useGooglePlaces from "@/hooks/useGooglePlaces";

interface BookingFormProps {
  onSubmit: (data: BookingFormData) => void;
}

export function BookingForm({ onSubmit }: BookingFormProps) {
  const [formData, setFormData] = useState<BookingFormData>({
    bookingType: "point-to-point",
    pickupLocation: "",
    dropoffLocation: "",
    pickupDate: "",
    pickupTime: "",
    passengers: 1,
    vehicleType: "sedan"
  });

  const pickupInputRef = useRef<HTMLInputElement>(null);
  const dropoffInputRef = useRef<HTMLInputElement>(null);

  const { isReady, error } = useGooglePlaces();

  useEffect(() => {
    if (isReady && pickupInputRef.current && dropoffInputRef.current) {
      const pickupAutocomplete = new window.google.maps.places.Autocomplete(
        pickupInputRef.current,
        { types: ["address"] }
      );

      const dropoffAutocomplete = new window.google.maps.places.Autocomplete(
        dropoffInputRef.current,
        { types: ["address"] }
      );

      pickupAutocomplete.addListener("place_changed", () => {
        const place = pickupAutocomplete.getPlace();
        setFormData(prev => ({
          ...prev,
          pickupLocation: place.formatted_address || ""
        }));
      });

      dropoffAutocomplete.addListener("place_changed", () => {
        const place = dropoffAutocomplete.getPlace();
        setFormData(prev => ({
          ...prev,
          dropoffLocation: place.formatted_address || ""
        }));
      });
    }
  }, [isReady]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  if (error) {
    console.error("Error loading Google Places:", error);
  }

  return (
    <Card className="p-6 bg-white/90 backdrop-blur-sm">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Input
            ref={pickupInputRef}
            type="text"
            placeholder="Pickup Location"
            required
            className="w-full"
          />
          <Input
            ref={dropoffInputRef}
            type="text"
            placeholder="Dropoff Location"
            required
            className="w-full"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Input
            type="date"
            required
            value={formData.pickupDate}
            onChange={(e) => setFormData(prev => ({ ...prev, pickupDate: e.target.value }))}
            min={new Date().toISOString().split("T")[0]}
          />
          <Input
            type="time"
            required
            value={formData.pickupTime}
            onChange={(e) => setFormData(prev => ({ ...prev, pickupTime: e.target.value }))}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Input
            type="number"
            min="1"
            max="8"
            value={formData.passengers}
            onChange={(e) => setFormData(prev => ({ ...prev, passengers: parseInt(e.target.value) }))}
            placeholder="Passengers"
          />
          <select
            value={formData.vehicleType}
            onChange={(e) => setFormData(prev => ({ ...prev, vehicleType: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="sedan">Sedan</option>
            <option value="suv">SUV</option>
            <option value="van">Van</option>
            <option value="luxury">Luxury</option>
          </select>
        </div>

        <Button type="submit" className="w-full">
          Book Now
        </Button>
      </form>
    </Card>
  );
}
