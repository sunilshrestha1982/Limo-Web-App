
import { configService } from "@/services/configService";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const robotsTxt = await configService.generateRobotsTxt();
    res.setHeader("Content-Type", "text/plain");
    res.write(robotsTxt);
    res.end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error generating robots.txt" });
  }
}
