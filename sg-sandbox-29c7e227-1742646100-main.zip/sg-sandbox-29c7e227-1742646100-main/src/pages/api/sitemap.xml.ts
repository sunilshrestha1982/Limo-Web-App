
import { configService } from "@/services/configService";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const sitemap = await configService.generateSitemap();
    res.setHeader("Content-Type", "text/xml");
    res.write(sitemap);
    res.end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error generating sitemap" });
  }
}
