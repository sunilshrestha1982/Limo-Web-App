
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function AboutPage() {
  return (
    <>
      <Head>
        <title>About Us | Premium Chauffeur Service</title>
        <meta name="description" content="Learn about our premium chauffeur service and commitment to excellence" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">About Us</h1>
          <p className="text-lg text-gray-600 mb-8">
            Learn about our premium chauffeur service and commitment to excellence.
          </p>
        </div>
      </main>

      <Footer />
    </>
  );
}
