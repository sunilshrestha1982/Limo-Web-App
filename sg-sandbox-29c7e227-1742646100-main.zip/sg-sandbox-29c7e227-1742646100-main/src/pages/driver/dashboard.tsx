
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { driverService } from "@/services/driverService";
import { Driver, DriverDocument } from "@/types/user";
import { DocumentUpload } from "@/components/driver/DocumentUpload";
import { NotificationPanel } from "@/components/driver/NotificationPanel";
import { storage } from "@/lib/firebase";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import Head from "next/head";
import { Skeleton } from "@/components/ui/skeleton";
import { ToastAction } from "@/components/ui/toast";
import { useToast } from "@/hooks/use-toast";

interface Notification {
  id: string;
  type: "booking" | "document" | "system";
  title: string;
  message: string;
  status: "unread" | "read";
  timestamp: string;
}

const DEMO_DRIVER_ID = "demo-driver-123";

export default function DriverDashboard() {
  const [driver, setDriver] = useState<Driver | null>(null);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const loadDriverData = async () => {
      try {
        let driverData = await driverService.getDriverById(DEMO_DRIVER_ID);
        
        if (!driverData) {
          await driverService.createDriver({
            userId: DEMO_DRIVER_ID,
            firstName: "Demo",
            lastName: "Driver",
            email: "demo@example.com",
            phone: "+1234567890",
            licenseNumber: "DL123456",
            licenseExpiry: new Date(2025, 11, 31).toISOString(),
            vehicleId: "demo-vehicle-1",
            status: "active",
            rating: 4.5,
            documents: []
          });
          driverData = await driverService.getDriverById(DEMO_DRIVER_ID);
          
          toast({
            title: "Demo Account Created",
            description: "A demo driver account has been created for testing purposes.",
          });
        }
        
        setDriver(driverData);
      } catch (error) {
        console.error("Error loading driver data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load driver data. Please try again.",
          action: <ToastAction altText="Try again">Try again</ToastAction>,
        });
      } finally {
        setLoading(false);
      }
    };

    loadDriverData();
  }, [toast]);

  const handleDocumentUpload = async (file: File, documentType: DriverDocument["type"]) => {
    if (!driver) return;

    try {
      const storageRef = ref(storage, `driver-documents/${driver.id}/${documentType}/${file.name}`);
      const snapshot = await uploadBytes(storageRef, file);
      const downloadUrl = await getDownloadURL(snapshot.ref);

      const documentId = await driverService.uploadDocument(driver.id, {
        type: documentType,
        url: downloadUrl,
        expiryDate: new Date().toISOString(),
        status: "pending",
        uploadedAt: new Date().toISOString()
      });

      const newNotification: Notification = {
        id: Date.now().toString(),
        type: "document",
        title: "Document Uploaded",
        message: `Your ${documentType.replace("_", " ")} has been uploaded and is pending review.`,
        status: "unread",
        timestamp: new Date().toISOString()
      };
      setNotifications(prev => [newNotification, ...prev]);

      toast({
        title: "Document Uploaded",
        description: `Your ${documentType.replace("_", " ")} has been uploaded successfully and is pending review.`,
      });
    } catch (error) {
      console.error("Error uploading document:", error);
      toast({
        variant: "destructive",
        title: "Upload Failed",
        description: "Failed to upload document. Please try again.",
        action: <ToastAction altText="Try again">Try again</ToastAction>,
      });
      throw error;
    }
  };

  const handleNotificationRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === notificationId
          ? { ...notification, status: "read" }
          : notification
      )
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-12 w-48 mb-8" />
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-24" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Head>
        <title>Driver Dashboard | Premium Chauffeur Service</title>
      </Head>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Driver Dashboard</h1>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span>Current Status</span>
                  <span className="capitalize">{driver?.status || "N/A"}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Rating</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span>Average Rating</span>
                  <span>{driver?.rating?.toFixed(1) || "N/A"} / 5.0</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span>Status</span>
                  <span className="capitalize">
                    {(driver?.documents?.length ?? 0) > 0 && driver?.documents?.every(doc => doc.status === "approved")
                      ? "All Approved"
                      : "Pending Review"}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Required Documents</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <DocumentUpload
                    documentType="license"
                    onUpload={(file) => handleDocumentUpload(file, "license")}
                  />
                  <DocumentUpload
                    documentType="insurance"
                    onUpload={(file) => handleDocumentUpload(file, "insurance")}
                  />
                  <DocumentUpload
                    documentType="background_check"
                    onUpload={(file) => handleDocumentUpload(file, "background_check")}
                  />
                  <DocumentUpload
                    documentType="vehicle_registration"
                    onUpload={(file) => handleDocumentUpload(file, "vehicle_registration")}
                  />
                </CardContent>
              </Card>
            </div>

            <div>
              <NotificationPanel
                notifications={notifications}
                onNotificationRead={handleNotificationRead}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
