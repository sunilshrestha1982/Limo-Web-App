
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function PrivacyPage() {
  return (
    <>
      <Head>
        <title>Privacy Policy | Premium Chauffeur Service</title>
        <meta name="description" content="Learn about how we protect your privacy and handle your data" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
          <div className="prose max-w-none">
            <h2>1. Information We Collect</h2>
            <p>Details about the types of personal information we collect.</p>
            
            <h2>2. How We Use Your Information</h2>
            <p>Explanation of how we use and protect your personal data.</p>
            
            <h2>3. Data Security</h2>
            <p>Information about our security measures and data protection.</p>
            
            <h2>4. Your Rights</h2>
            <p>Details about your rights regarding your personal data.</p>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}
