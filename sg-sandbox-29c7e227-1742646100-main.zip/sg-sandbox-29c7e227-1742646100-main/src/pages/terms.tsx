
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function TermsPage() {
  return (
    <>
      <Head>
        <title>Terms of Service | Premium Chauffeur Service</title>
        <meta name="description" content="Read our terms of service and booking conditions" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
          <div className="prose max-w-none">
            <h2>1. Acceptance of Terms</h2>
            <p>By accessing and using our services, you agree to be bound by these terms.</p>
            
            <h2>2. Service Description</h2>
            <p>We provide premium chauffeur and transportation services worldwide.</p>
            
            <h2>3. Booking and Cancellation</h2>
            <p>Detailed information about our booking and cancellation policies.</p>
            
            <h2>4. Payment Terms</h2>
            <p>Information about payment methods, pricing, and refund policies.</p>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}
