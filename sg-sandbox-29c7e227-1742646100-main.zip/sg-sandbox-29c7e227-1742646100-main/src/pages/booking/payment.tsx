
import { useState } from "react";
import { PaymentForm } from "@/components/payment/PaymentForm";
import { TipSelector } from "@/components/payment/TipSelector";
import { CouponInput } from "@/components/payment/CouponInput";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PaymentMethod } from "@/types/payment";
import { paymentService } from "@/services/paymentService";

export default function PaymentPage() {
  const [baseAmount] = useState(150); // This would come from the booking
  const [tipAmount, setTipAmount] = useState(0);
  const [discountAmount, setDiscountAmount] = useState(0);

  const totalAmount = baseAmount + tipAmount - discountAmount;

  const handlePaymentSubmit = async (paymentMethod: PaymentMethod) => {
    try {
      // This would integrate with Stripe
      const paymentIntent = await paymentService.createPaymentIntent(
        "booking-id", // This would come from the booking
        totalAmount,
        paymentMethod.id
      );
      
      console.log("Payment processed:", paymentIntent);
      // Handle successful payment
    } catch (error) {
      console.error("Payment failed:", error);
      // Handle payment error
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Complete Your Payment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Base Amount:</span>
                  <span>${baseAmount.toFixed(2)}</span>
                </div>
                {tipAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Tip:</span>
                    <span>${tipAmount.toFixed(2)}</span>
                  </div>
                )}
                {discountAmount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount:</span>
                    <span>-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg">
                  <span>Total:</span>
                  <span>${totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <TipSelector amount={baseAmount} onTipChange={setTipAmount} />
        
        <CouponInput amount={baseAmount} onCouponApply={setDiscountAmount} />
        
        <PaymentForm amount={totalAmount} onSubmit={handlePaymentSubmit} />
      </div>
    </div>
  );
}
