import { BookingForm } from "@/components/booking/BookingForm";
import { VehicleCard } from "@/components/booking/VehicleCard";
import { BookingFormData, Vehicle } from "@/types/booking";
import { useState } from "react";
import Head from "next/head";
import Image from "next/image";
import { ReviewSection } from '@/components/home/ReviewSection';
import { LocationSection } from '@/components/home/LocationSection';
import { Footer } from '@/components/layout/Footer';
import { BannerSlider } from '@/components/home/BannerSlider';

const demoVehicles: Vehicle[] = [
  {
    id: "1",
    name: "First Class",
    type: "sedan",
    capacity: 3,
    hourlyRate: 95,
    baseRate: 180,
    description: "Mercedes-Benz S-Class or similar",
    imageUrl: "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&h=600",
    available: true
  },
  {
    id: "2",
    name: "Business Van",
    type: "van",
    capacity: 5,
    hourlyRate: 120,
    baseRate: 220,
    description: "Mercedes-Benz V-Class or similar",
    imageUrl: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&h=600",
    available: true
  },
  {
    id: "3",
    name: "Business Class",
    type: "sedan",
    capacity: 3,
    hourlyRate: 85,
    baseRate: 160,
    description: "BMW 5 Series or similar",
    imageUrl: "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&h=600",
    available: true
  }
];

export default function Home() {
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);

  const handleBookingSubmit = (data: BookingFormData) => {
    console.log("Booking submitted:", data);
    // TODO: Implement booking submission
  };

  return (
    <>
      <Head>
        <title>Premium Chauffeur Service | Global Ground Transportation</title>
        <meta name="description" content="Experience world-class chauffeur service with our professional drivers and luxury vehicles" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="min-h-screen">
        {/* Hero Section */}
        <BannerSlider />
        <div className="relative h-[80vh] w-full">
          <Image
            src="https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=1920&h=1080"
            alt="Luxury car service"
            fill
            className="object-cover brightness-50"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/20">
            <div className="container mx-auto px-4 h-full flex flex-col justify-center">
              <div className="max-w-3xl">
                <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
                  Your Premium Chauffeur Service Worldwide
                </h1>
                <p className="text-xl text-white/90 mb-12">
                  Professional drivers, luxury vehicles, and world-class service in over 50 countries
                </p>
              </div>
              <div className="w-full max-w-lg">
                <BookingForm onSubmit={handleBookingSubmit} />
              </div>
            </div>
          </div>
        </div>

        {/* Vehicle Selection Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Select Your Vehicle Class
              </h2>
              <p className="text-lg text-gray-600">
                Choose from our range of premium vehicles
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {demoVehicles.map((vehicle) => (
                <VehicleCard
                  key={vehicle.id}
                  vehicle={vehicle}
                  onSelect={setSelectedVehicle}
                  selected={selectedVehicle?.id === vehicle.id}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-12">
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-4">All-inclusive Rates</h3>
                <p className="text-gray-600">No hidden fees. All taxes, tolls, and gratuities included.</p>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-4">Professional Chauffeurs</h3>
                <p className="text-gray-600">Experienced, licensed, and professionally trained drivers.</p>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-4">24/7 Support</h3>
                <p className="text-gray-600">Round-the-clock customer service in multiple languages.</p>
              </div>
            </div>
          </div>
        </section>

        <ReviewSection />
        <LocationSection />
      </main>

      <Footer />
    </>
  );
}