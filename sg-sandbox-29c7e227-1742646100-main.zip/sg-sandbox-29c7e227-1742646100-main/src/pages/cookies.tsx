
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function CookiesPage() {
  return (
    <>
      <Head>
        <title>Cookie Policy | Premium Chauffeur Service</title>
        <meta name="description" content="Learn about how we use cookies on our website" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">Cookie Policy</h1>
          <div className="prose max-w-none">
            <h2>1. What Are Cookies</h2>
            <p>Explanation of cookies and how they work.</p>
            
            <h2>2. How We Use Cookies</h2>
            <p>Details about the types of cookies we use and their purpose.</p>
            
            <h2>3. Managing Cookies</h2>
            <p>Information about how to manage or disable cookies in your browser.</p>
            
            <h2>4. Third-Party Cookies</h2>
            <p>Information about third-party cookies used on our website.</p>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}
