
import { useRouter } from "next/router";
import Head from "next/head";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookingForm } from "@/components/booking/BookingForm";

export default function CityPage() {
  const router = useRouter();
  const { slug } = router.query;

  // TODO: Fetch city data from Firebase based on slug
  const cityData = {
    name: "New York",
    title: "Chauffeur Service in New York",
    description: "Experience luxury transportation in New York with our premium chauffeur service. Professional drivers, luxury vehicles, and world-class service available 24/7.",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=1920&h=1080",
    features: [
      "Airport transfers to/from JFK, LaGuardia, and Newark",
      "Hourly booking for business meetings or city tours",
      "Corporate event transportation",
      "Luxury vehicle fleet including Mercedes-Benz S-Class and BMW 7 Series"
    ]
  };

  return (
    <>
      <Head>
        <title>{cityData.title} | Premium Chauffeur Service</title>
        <meta name="description" content={cityData.description} />
      </Head>

      <main>
        <div className="relative h-[60vh] w-full">
          <Image
            src={cityData.image}
            alt={cityData.name}
            fill
            className="object-cover brightness-50"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/20">
            <div className="container mx-auto px-4 h-full flex flex-col justify-center">
              <div className="max-w-3xl">
                <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
                  {cityData.title}
                </h1>
                <p className="text-xl text-white/90 mb-12">
                  {cityData.description}
                </p>
              </div>
            </div>
          </div>
        </div>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Our Services in {cityData.name}</h2>
                <div className="space-y-4">
                  {cityData.features.map((feature, index) => (
                    <Card key={index} className="p-4">
                      <p>{feature}</p>
                    </Card>
                  ))}
                </div>
              </div>
              <div>
                <Card className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Book Your Ride</h3>
                  <BookingForm onSubmit={(data) => console.log(data)} />
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
