
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function ContactPage() {
  return (
    <>
      <Head>
        <title>Contact Us | Premium Chauffeur Service</title>
        <meta name="description" content="Get in touch with our team for inquiries and support" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">Contact Us</h1>
          <p className="text-lg text-gray-600 mb-8">
            Get in touch with our team for inquiries and support.
          </p>
        </div>
      </main>

      <Footer />
    </>
  );
}
