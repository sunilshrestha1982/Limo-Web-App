
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function HourlyBookingPage() {
  return (
    <>
      <Head>
        <title>Hourly Chauffeur Service | Premium Chauffeur Service</title>
        <meta name="description" content="Book a luxury chauffeur service by the hour for meetings, events, or city tours" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">Hourly Chauffeur Service</h1>
          <p className="text-lg text-gray-600 mb-8">
            Book a luxury chauffeur service by the hour for meetings, events, or city tours.
          </p>
        </div>
      </main>

      <Footer />
    </>
  );
}
