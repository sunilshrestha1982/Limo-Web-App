
import Head from "next/head";
import { Footer } from "@/components/layout/Footer";

export default function AirportTransferPage() {
  return (
    <>
      <Head>
        <title>Airport Transfer Service | Premium Chauffeur Service</title>
        <meta name="description" content="Professional airport transfer services with luxury vehicles and experienced chauffeurs" />
      </Head>

      <main className="min-h-screen">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl font-bold mb-8">Airport Transfer Service</h1>
          <p className="text-lg text-gray-600 mb-8">
            Professional airport transfer services with luxury vehicles and experienced chauffeurs.
          </p>
        </div>
      </main>

      <Footer />
    </>
  );
}
