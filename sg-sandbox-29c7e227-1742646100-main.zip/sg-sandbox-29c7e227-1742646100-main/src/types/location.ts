
export interface Location {
  id: string;
  name: string;
  type: "airport" | "seaport" | "city" | "zone";
  coordinates: {
    lat: number;
    lng: number;
  };
  address: string;
  code?: string; // For airports/seaports
}

export interface RateZone {
  id: string;
  name: string;
  boundaries: {
    lat: number;
    lng: number;
    radius: number; // in kilometers
  };
}

export interface Rate {
  id: string;
  fromLocationId: string;
  toLocationId: string;
  vehicleType: string;
  baseRate: number;
  perKmRate: number;
  minimumFare: number;
  currency: string;
  specialRates?: {
    nightRate?: number; // Percentage increase
    peakHourRate?: number; // Percentage increase
    holidayRate?: number; // Percentage increase
  };
}
