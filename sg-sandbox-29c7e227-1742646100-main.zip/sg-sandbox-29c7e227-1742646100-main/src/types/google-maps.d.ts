
declare namespace google.maps {
  export class places {
    static AutocompleteService: typeof AutocompleteService;
    static PlacesService: typeof PlacesService;
    static Autocomplete: typeof Autocomplete;
  }

  export class Autocomplete {
    constructor(inputField: HTMLInputElement, options?: AutocompleteOptions);
    addListener(eventName: string, handler: () => void): void;
    getPlace(): PlaceResult;
  }

  export interface AutocompleteOptions {
    types?: string[];
    componentRestrictions?: ComponentRestrictions;
    fields?: string[];
    bounds?: LatLngBounds;
  }

  export class AutocompleteService {
    getPlacePredictions(
      request: AutocompletionRequest,
      callback: (results: AutocompletePrediction[], status: PlacesServiceStatus) => void
    ): void;
  }

  export class PlacesService {
    constructor(attrContainer: Element | Map);
    getDetails(
      request: PlaceDetailsRequest,
      callback: (result: PlaceResult | null, status: PlacesServiceStatus) => void
    ): void;
  }

  export interface AutocompletionRequest {
    input: string;
    types?: string[];
    componentRestrictions?: ComponentRestrictions;
  }

  export interface ComponentRestrictions {
    country: string | string[];
  }

  export interface PlaceDetailsRequest {
    placeId: string;
    fields?: string[];
  }

  export interface PlaceResult {
    formatted_address?: string;
    geometry?: {
      location: LatLng;
    };
    place_id?: string;
    name?: string;
  }

  export class LatLng {
    constructor(lat: number, lng: number);
    lat(): number;
    lng(): number;
  }

  export class LatLngBounds {
    constructor(sw: LatLng, ne: LatLng);
    extend(point: LatLng): LatLngBounds;
    getCenter(): LatLng;
    getNorthEast(): LatLng;
    getSouthWest(): LatLng;
  }

  export type PlacesServiceStatus = 'OK' | 'ZERO_RESULTS' | 'ERROR';

  export interface AutocompletePrediction {
    description: string;
    place_id: string;
    structured_formatting: {
      main_text: string;
      secondary_text: string;
    };
  }
}

declare global {
  interface Window {
    google: typeof google;
  }
}
