
export interface Banner {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  status: "active" | "inactive";
  order: number;
  ctaText?: string;
  ctaLink?: string;
}
