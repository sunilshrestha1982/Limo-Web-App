
export interface SiteConfig {
  id: string;
  googleAnalyticsId?: string;
  googleSearchConsoleId?: string;
  branding: {
    logo: {
      light: string;
      dark: string;
    };
    slogan: string;
    colors: {
      primary: string;
      secondary: string;
    };
  };
  metaTags: {
    defaultTitle: string;
    defaultDescription: string;
    pages: {
      [key: string]: {
        title: string;
        description: string;
      }
    }
  };
  paymentGateways: {
    stripe?: {
      publicKey: string;
      secretKey: string;
      webhookSecret: string;
    };
    authorizeNet?: {
      apiLoginId: string;
      transactionKey: string;
      sandboxMode: boolean;
    };
  };
}

export interface SeoConfig {
  id: string;
  pageUrl: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  ogImage?: string;
  lastModified: string;
}
