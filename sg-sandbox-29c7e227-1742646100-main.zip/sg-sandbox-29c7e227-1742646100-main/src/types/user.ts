
export interface Driver {
  id: string;
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  licenseNumber: string;
  licenseExpiry: string;
  vehicleId: string;
  status: "active" | "inactive" | "pending";
  rating: number;
  documents: DriverDocument[];
}

export interface DriverDocument {
  id: string;
  type: "license" | "insurance" | "background_check" | "vehicle_registration";
  url: string;
  expiryDate: string;
  status: "pending" | "approved" | "rejected";
  uploadedAt: string;
}

export interface Passenger {
  id: string;
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  preferredPaymentMethod?: string;
  savedAddresses: SavedAddress[];
}

export interface SavedAddress {
  id: string;
  type: "home" | "work" | "other";
  address: string;
  lat: number;
  lng: number;
}
