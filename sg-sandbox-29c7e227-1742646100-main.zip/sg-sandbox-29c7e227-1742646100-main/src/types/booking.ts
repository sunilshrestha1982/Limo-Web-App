
export interface Vehicle {
  id: string;
  name: string;
  type: "sedan" | "suv" | "luxury" | "van";
  capacity: number;
  hourlyRate: number;
  baseRate: number;
  description: string;
  imageUrl: string;
  available: boolean;
}

export interface Booking {
  id: string;
  userId: string;
  vehicleId: string;
  pickupLocation: {
    address: string;
    lat: number;
    lng: number;
  };
  dropoffLocation: {
    address: string;
    lat: number;
    lng: number;
  };
  pickupDate: string;
  pickupTime: string;
  bookingType: "point-to-point" | "hourly" | "airport";
  status: "pending" | "confirmed" | "completed" | "cancelled";
  price: number;
  duration: number;
  distance: number;
  createdAt: string;
  updatedAt: string;
}

export interface BookingFormData {
  bookingType: "point-to-point" | "hourly" | "airport";
  pickupLocation: string;
  dropoffLocation: string;
  pickupDate: string;
  pickupTime: string;
  vehicleType: string;
  passengers: number;
}
