export interface PaymentMethod {
  id: string;
  type: "credit_card" | "google_pay" | "apple_pay" | "authorize_net";
  last4?: string;
  brand?: string;
  expiryMonth?: number;
  expiryYear?: number;
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: "pending" | "succeeded" | "failed";
  paymentMethodId: string;
  bookingId: string;
  tipAmount?: number;
  discountAmount?: number;
  couponCode?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountAmount: number;
  validUntil: string;
  minimumAmount?: number;
  maxUses?: number;
  currentUses: number;
  status: 'active' | 'inactive';
  createdAt: string;
  lastUsedAt?: string;
  deactivatedAt?: string;
}