import { db } from "@/lib/firebase";
import { collection, doc, setDoc } from "firebase/firestore";

const siteConfig = {
  id: 'site',
  branding: {
    logo: {
      light: 'https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=120&h=40',
      dark: 'https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=120&h=40'
    },
    slogan: 'Premium Chauffeur Service',
    colors: {
      primary: '#1a1a1a',
      secondary: '#d4af37'
    }
  },
  metaTags: {
    defaultTitle: 'Premium Chauffeur Service | Global Ground Transportation',
    defaultDescription: 'Experience world-class chauffeur service with our professional drivers and luxury vehicles',
    pages: {
      home: {
        title: 'Premium Chauffeur Service | Global Ground Transportation',
        description: 'Experience world-class chauffeur service with our professional drivers and luxury vehicles'
      }
    }
  },
  paymentGateways: {
    stripe: {
      publicKey: process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY || '',
      secretKey: process.env.STRIPE_SECRET_KEY || '',
      webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || ''
    }
  }
};

const initialBanners = [
  {
    id: 'banner1',
    title: 'Premium Chauffeur Service',
    subtitle: 'Experience luxury and comfort worldwide',
    imageUrl: 'https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=1920&h=1080',
    buttonText: 'Book Now',
    buttonLink: '/booking',
    order: 1,
    status: 'active',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'banner2',
    title: 'Airport Transfers',
    subtitle: 'Professional service at all major airports',
    imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1920&h=1080',
    buttonText: 'Learn More',
    buttonLink: '/services/airport-transfer',
    order: 2,
    status: 'active',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export async function initializeFirestore() {
  try {
    // Initialize site config
    await setDoc(doc(db, "config", "site"), siteConfig);
    console.log("Site config initialized");

    // Initialize banners
    for (const banner of initialBanners) {
      await setDoc(doc(collection(db, "banners"), banner.id), banner);
    }
    console.log("Banners initialized");

  } catch (error) {
    console.error("Error initializing Firestore:", error);
    throw error;
  }
}