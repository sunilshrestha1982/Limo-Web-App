import { db } from "@/lib/firebase";
import { doc, setDoc, collection, getDocs } from "firebase/firestore";

async function initializeData() {
  try {
    // Initialize site config
    const configRef = doc(db, 'config', 'site');
    await setDoc(configRef, {
      branding: {
        logo: {
          light: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=120&h=40&q=80&fit=crop',
          dark: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=120&h=40&q=80&fit=crop'
        },
        slogan: 'Premium Chauffeur Service'
      }
    }, { merge: true });

    // Initialize banners
    const bannersRef = collection(db, 'banners');
    await setDoc(doc(bannersRef, 'banner1'), {
      title: 'Premium Chauffeur Service',
      subtitle: 'Experience luxury and comfort worldwide',
      imageUrl: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=1920&h=1080&q=80&fit=crop',
      buttonText: 'Book Now',
      buttonLink: '/booking',
      order: 1,
      status: 'active'
    });

    await setDoc(doc(bannersRef, 'banner2'), {
      title: 'Luxury Fleet',
      subtitle: 'Choose from our premium selection of vehicles',
      imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1920&h=1080&q=80&fit=crop',
      buttonText: 'View Fleet',
      buttonLink: '/fleet',
      order: 2,
      status: 'active'
    });

    console.log('Data initialization completed successfully');
  } catch (error) {
    console.error('Error initializing data:', error);
  }
}

initializeData();