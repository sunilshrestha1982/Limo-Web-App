
import { db } from "@/lib/firebase";
import { doc, setDoc } from "firebase/firestore";

async function initializeFirestore() {
  try {
    await setDoc(doc(db, "config", "site"), {
      branding: {
        logo: {
          light: "https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=120&h=40",
          dark: "https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=120&h=40"
        },
        slogan: "Premium Chauffeur Service"
      }
    }, { merge: true });

    await setDoc(doc(db, "banners", "banner1"), {
      title: "Premium Chauffeur Service",
      subtitle: "Experience luxury and comfort worldwide",
      imageUrl: "https://images.unsplash.com/photo-1611288875785-9b295888e80f?w=1920&h=1080",
      buttonText: "Book Now",
      buttonLink: "/booking",
      order: 1,
      status: "active"
    }, { merge: true });

    console.log("Firestore initialized successfully");
  } catch (error) {
    console.error("Error initializing Firestore:", error);
  }
}

initializeFirestore();
