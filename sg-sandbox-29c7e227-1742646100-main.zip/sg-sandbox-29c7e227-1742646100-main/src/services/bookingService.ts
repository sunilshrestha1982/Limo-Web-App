
import { db } from "@/lib/firebase";
import { collection, addDoc, getDocs, doc, updateDoc, deleteDoc, query, where } from "firebase/firestore";
import { Booking, Vehicle } from "@/types/booking";

export const bookingService = {
  async createBooking(bookingData: Partial<Booking>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, "bookings"), {
        ...bookingData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: "pending"
      });
      return docRef.id;
    } catch (error) {
      console.error("Error creating booking:", error);
      throw error;
    }
  },

  async getVehicles(): Promise<Vehicle[]> {
    try {
      const querySnapshot = await getDocs(collection(db, "vehicles"));
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Vehicle));
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      throw error;
    }
  },

  async getUserBookings(userId: string): Promise<Booking[]> {
    try {
      const q = query(collection(db, "bookings"), where("userId", "==", userId));
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Booking));
    } catch (error) {
      console.error("Error fetching user bookings:", error);
      throw error;
    }
  }
};
