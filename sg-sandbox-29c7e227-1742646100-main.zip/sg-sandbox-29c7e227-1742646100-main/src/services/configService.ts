
import { db } from "@/lib/firebase";
import { collection, doc, getDoc, setDoc, updateDoc, getDocs } from "firebase/firestore";
import { SiteConfig, SeoConfig } from "@/types/config";

export const configService = {
  async getSiteConfig(): Promise<SiteConfig | null> {
    try {
      const docRef = doc(db, "config", "site");
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) return null;
      return docSnap.data() as SiteConfig;
    } catch (error) {
      console.error("Error fetching site config:", error);
      throw error;
    }
  },

  async updateSiteConfig(config: Partial<SiteConfig>): Promise<void> {
    try {
      const docRef = doc(db, "config", "site");
      await updateDoc(docRef, config);
    } catch (error) {
      console.error("Error updating site config:", error);
      throw error;
    }
  },

  async getPageSeoConfig(pageUrl: string): Promise<SeoConfig | null> {
    try {
      const docRef = doc(collection(db, "seoConfig"), pageUrl);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) return null;
      return docSnap.data() as SeoConfig;
    } catch (error) {
      console.error("Error fetching SEO config:", error);
      throw error;
    }
  },

  async updatePageSeoConfig(pageUrl: string, config: Partial<SeoConfig>): Promise<void> {
    try {
      await setDoc(doc(collection(db, "seoConfig"), pageUrl), {
        ...config,
        pageUrl,
        lastModified: new Date().toISOString()
      }, { merge: true });
    } catch (error) {
      console.error("Error updating SEO config:", error);
      throw error;
    }
  },

  async generateSitemap(): Promise<string> {
    try {
      const querySnapshot = await getDocs(collection(db, "seoConfig"));
      let sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n';
      sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
      
      querySnapshot.forEach((doc) => {
        const data = doc.data() as SeoConfig;
        sitemap += `  <url>\n`;
        sitemap += `    <loc>${data.pageUrl}</loc>\n`;
        sitemap += `    <lastmod>${data.lastModified}</lastmod>\n`;
        sitemap += `  </url>\n`;
      });
      
      sitemap += '</urlset>';
      return sitemap;
    } catch (error) {
      console.error("Error generating sitemap:", error);
      throw error;
    }
  },

  async generateRobotsTxt(): Promise<string> {
    const siteConfig = await this.getSiteConfig();
    return `
User-agent: *
Allow: /
Sitemap: ${process.env.NEXT_PUBLIC_SITE_URL}/sitemap.xml
${siteConfig?.googleSearchConsoleId ? `google-site-verification: ${siteConfig.googleSearchConsoleId}` : ""}
    `.trim();
  }
};
