
import { db } from "@/lib/firebase";
import { collection, addDoc, query as firestoreQuery, where, getDocs } from "firebase/firestore";
import { Location, Rate, RateZone } from "@/types/location";

const toRad = (value: number): number => {
  return value * Math.PI / 180;
};

export const locationService = {
  async createLocation(locationData: Partial<Location>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, "locations"), {
        ...locationData,
        createdAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      console.error("Error creating location:", error);
      throw error;
    }
  },

  async createRate(rateData: Partial<Rate>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, "rates"), {
        ...rateData,
        createdAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      console.error("Error creating rate:", error);
      throw error;
    }
  },

  async getRateByLocations(fromLocationId: string, toLocationId: string, vehicleType: string): Promise<Rate | null> {
    try {
      const q = firestoreQuery(
        collection(db, "rates"),
        where("fromLocationId", "==", fromLocationId),
        where("toLocationId", "==", toLocationId),
        where("vehicleType", "==", vehicleType)
      );
      
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) return null;
      
      return {
        id: querySnapshot.docs[0].id,
        ...querySnapshot.docs[0].data()
      } as Rate;
    } catch (error) {
      console.error("Error fetching rate:", error);
      throw error;
    }
  },

  async searchLocations(searchQuery: string, type?: Location["type"]): Promise<Location[]> {
    try {
      let q;
      if (type) {
        q = firestoreQuery(
          collection(db, "locations"),
          where("type", "==", type)
        );
      } else {
        q = firestoreQuery(collection(db, "locations"));
      }
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Location));
    } catch (error) {
      console.error("Error searching locations:", error);
      throw error;
    }
  },

  async getLocationsByType(type: Location["type"]): Promise<Location[]> {
    try {
      const q = firestoreQuery(
        collection(db, "locations"),
        where("type", "==", type)
      );
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Location));
    } catch (error) {
      console.error("Error fetching locations by type:", error);
      throw error;
    }
  },

  async calculateDistance(fromLocation: Location, toLocation: Location): Promise<number> {
    // This would integrate with Google Maps Distance Matrix API
    // For now, return a simple calculation based on coordinates
    const R = 6371; // Earth's radius in km
    const dLat = toRad(toLocation.coordinates.lat - fromLocation.coordinates.lat);
    const dLon = toRad(toLocation.coordinates.lng - fromLocation.coordinates.lng);
    const lat1 = toRad(fromLocation.coordinates.lat);
    const lat2 = toRad(toLocation.coordinates.lat);

    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
};
