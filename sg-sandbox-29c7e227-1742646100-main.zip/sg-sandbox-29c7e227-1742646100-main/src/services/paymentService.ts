
import { db } from "@/lib/firebase";
import { collection, addDoc, query, where, getDocs } from "firebase/firestore";
import { PaymentIntent, PaymentMethod, Coupon } from "@/types/payment";

export const paymentService = {
  async createPaymentIntent(bookingId: string, amount: number, paymentMethodId: string): Promise<PaymentIntent> {
    try {
      const paymentIntent = {
        amount,
        currency: "USD",
        status: "pending",
        paymentMethodId,
        bookingId,
        createdAt: new Date().toISOString()
      };

      const docRef = await addDoc(collection(db, "paymentIntents"), paymentIntent);
      return { id: docRef.id, ...paymentIntent } as PaymentIntent;
    } catch (error) {
      console.error("Error creating payment intent:", error);
      throw error;
    }
  },

  async validateCoupon(code: string, amount: number): Promise<Coupon | null> {
    try {
      const q = query(collection(db, "coupons"), where("code", "==", code));
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) return null;
      
      const coupon = { id: querySnapshot.docs[0].id, ...querySnapshot.docs[0].data() } as Coupon;
      
      if (new Date(coupon.validUntil) < new Date()) return null;
      if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) return null;
      if (coupon.minimumAmount && amount < coupon.minimumAmount) return null;
      
      return coupon;
    } catch (error) {
      console.error("Error validating coupon:", error);
      throw error;
    }
  },

  async calculateDiscount(amount: number, coupon: Coupon): Promise<number> {
    if (coupon.discountType === "percentage") {
      return (amount * coupon.discountAmount) / 100;
    }
    return coupon.discountAmount;
  }
};
