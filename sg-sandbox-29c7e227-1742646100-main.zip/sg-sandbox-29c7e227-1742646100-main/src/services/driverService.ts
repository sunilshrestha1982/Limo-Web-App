
import { db } from "@/lib/firebase";
import { collection, doc, getDoc, setDoc, addDoc } from "firebase/firestore";
import { Driver, DriverDocument } from "@/types/user";

export const driverService = {
  async createDriver(driverData: Partial<Driver>): Promise<string> {
    try {
      // For demo driver, use a specific document ID
      if (driverData.userId === "demo-driver-123") {
        const driverRef = doc(db, "drivers", "demo-driver-123");
        await setDoc(driverRef, {
          ...driverData,
          id: "demo-driver-123",
          status: "active",
          rating: 4.5,
          documents: [],
          createdAt: new Date().toISOString()
        });
        return "demo-driver-123";
      }

      // For regular drivers, create with auto-generated ID
      const docRef = await addDoc(collection(db, "drivers"), {
        ...driverData,
        status: "pending",
        rating: 0,
        documents: [],
        createdAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      console.error("Error creating driver:", error);
      throw new Error("Failed to create driver profile");
    }
  },

  async getDriverById(driverId: string): Promise<Driver | null> {
    try {
      const docRef = doc(db, "drivers", driverId);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) return null;
      
      return { id: docSnap.id, ...docSnap.data() } as Driver;
    } catch (error) {
      console.error("Error fetching driver:", error);
      throw new Error("Failed to fetch driver profile");
    }
  },

  async uploadDocument(driverId: string, document: Partial<DriverDocument>): Promise<string> {
    try {
      // Create document in the driver's documents subcollection
      const docRef = await addDoc(collection(db, `drivers/${driverId}/documents`), {
        ...document,
        status: "pending",
        uploadedAt: new Date().toISOString()
      });

      // Also add to driverDocuments collection for admin access
      await addDoc(collection(db, "driverDocuments"), {
        driverId,
        documentId: docRef.id,
        ...document,
        status: "pending",
        uploadedAt: new Date().toISOString()
      });

      return docRef.id;
    } catch (error) {
      console.error("Error uploading document:", error);
      throw new Error("Failed to upload document");
    }
  }
};
