
import { db } from "@/lib/firebase";
import { collection, addDoc, query, where, getDocs, updateDoc, doc, increment } from "firebase/firestore";
import { Coupon } from "@/types/payment";

export const couponService = {
  async generateCoupon(data: Partial<Coupon>): Promise<string> {
    try {
      const code = await this.generateUniqueCode();
      const couponData = {
        ...data,
        code,
        currentUses: 0,
        createdAt: new Date().toISOString(),
        status: "active"
      };

      const docRef = await addDoc(collection(db, "coupons"), couponData);
      return docRef.id;
    } catch (error) {
      console.error("Error generating coupon:", error);
      throw error;
    }
  },

  async generateUniqueCode(): Promise<string> {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code: string;
    let isUnique = false;

    while (!isUnique) {
      code = "";
      for (let i = 0; i < 8; i++) {
        code += characters.charAt(Math.floor(Math.random() * characters.length));
      }

      const q = query(collection(db, "coupons"), where("code", "==", code));
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        isUnique = true;
        return code;
      }
    }

    throw new Error("Could not generate unique code");
  },

  async incrementCouponUse(couponId: string): Promise<void> {
    try {
      const couponRef = doc(db, "coupons", couponId);
      await updateDoc(couponRef, {
        currentUses: increment(1),
        lastUsedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error incrementing coupon use:", error);
      throw error;
    }
  },

  async validateCouponCode(code: string, amount: number): Promise<Coupon | null> {
    try {
      const q = query(
        collection(db, "coupons"), 
        where("code", "==", code),
        where("status", "==", "active")
      );
      
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) return null;

      const coupon = { 
        id: querySnapshot.docs[0].id, 
        ...querySnapshot.docs[0].data() 
      } as Coupon;

      // Validate coupon
      if (new Date(coupon.validUntil) < new Date()) return null;
      if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) return null;
      if (coupon.minimumAmount && amount < coupon.minimumAmount) return null;

      return coupon;
    } catch (error) {
      console.error("Error validating coupon:", error);
      throw error;
    }
  },

  async deactivateCoupon(couponId: string): Promise<void> {
    try {
      const couponRef = doc(db, "coupons", couponId);
      await updateDoc(couponRef, {
        status: "inactive",
        deactivatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error deactivating coupon:", error);
      throw error;
    }
  }
};
