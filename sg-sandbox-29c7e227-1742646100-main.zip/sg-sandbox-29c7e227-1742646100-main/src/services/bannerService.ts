
import { collection, query, where, orderBy, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Banner } from "@/types/banner";

export const getActiveBanners = async (): Promise<Banner[]> => {
  try {
    const bannersRef = collection(db, "banners");
    const q = query(
      bannersRef,
      where("status", "==", "active"),
      orderBy("order", "asc")
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data() as Omit<Banner, "id">
    }));
  } catch (error) {
    console.error("Error fetching banners:", error);
    return [];
  }
};
