
import { db } from "@/lib/firebase";
import { collection, addDoc, query, where, getDocs, updateDoc, doc } from "firebase/firestore";
import { Passenger, SavedAddress } from "@/types/user";

export const passengerService = {
  async createPassenger(passengerData: Partial<Passenger>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, "passengers"), {
        ...passengerData,
        savedAddresses: [],
        createdAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      console.error("Error creating passenger:", error);
      throw error;
    }
  },

  async getPassengerById(passengerId: string): Promise<Passenger | null> {
    try {
      const q = query(collection(db, "passengers"), where("id", "==", passengerId));
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) return null;
      
      return { id: querySnapshot.docs[0].id, ...querySnapshot.docs[0].data() } as Passenger;
    } catch (error) {
      console.error("Error fetching passenger:", error);
      throw error;
    }
  },

  async addSavedAddress(passengerId: string, address: SavedAddress): Promise<string> {
    try {
      const passenger = await this.getPassengerById(passengerId);
      if (!passenger) throw new Error("Passenger not found");

      const updatedAddresses = [...passenger.savedAddresses, address];
      await updateDoc(doc(db, "passengers", passengerId), {
        savedAddresses: updatedAddresses
      });

      return address.id;
    } catch (error) {
      console.error("Error adding saved address:", error);
      throw error;
    }
  }
};
